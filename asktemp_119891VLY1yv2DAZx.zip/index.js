'use strict';
var Alexa = require("alexa-sdk");
var quizContent = require("quiz_config.js");
var rootURL = 'https://s3.amazonaws.com/simoncalexa/soundquiz';
var questions;



// For detailed tutorial on how to making a Alexa skill,
// please visit us at http://alexa.design/build


exports.handler = function(event, context) {
    var alexa = Alexa.handler(event, context);
    alexa.registerHandlers(handlers);
    alexa.execute();
};

var handlers = {
    'LaunchRequest': function () {
        init();
        this.response.speak("Hiya! Welcome to the music quiz - I'll play you a few seconds of a tune and then ask you what it is");
        this.emit('QuestionIntent');
    },
    'QuestionIntent': function () {
        this.response.speak("Question " + (questionIndex+1) + " of " + questions.length + " ...what tune is this?" + " <audio src=" + rootURL + questions[questionIndex].src + "/> Is it A " + questions[questionIndex].a + " or B " + questions[questionIndex].b ).listen("answer A or B");
        this.emit(":responseReady");
    },
    'AnswerIntent': function () {

        this.emit('QuestionIntent');
    },
    'SayHello': function () {
        this.response.speak('Hello World!')
                     .cardRenderer('hello world', 'hello world');
        this.emit(':responseReady');
    },
    'SayHelloName': function () {
        var name = this.event.request.intent.slots.name.value;
        this.response.speak('Hello ' + name)
            .cardRenderer('hello world', 'hello ' + name);
        this.emit(':responseReady');
    },
    'SessionEndedRequest' : function() {
        console.log('Session ended with reason: ' + this.event.request.reason);
    },
    'AMAZON.StopIntent' : function() {
        this.response.speak('Thanks for playing, see you soon!');
        this.emit(':responseReady');
    },
    'AMAZON.HelpIntent' : function() {
        this.response.speak("You can try: 'alexa, hello world' or 'alexa, ask hello world my" +
            " name is awesome Aaron'");
        this.emit(':responseReady');
    },
    'AMAZON.CancelIntent' : function() {
        this.response.speak('Bye');
        this.emit(':responseReady');
    },
    'Unhandled' : function() {
        this.response.speak("Sorry, I didn't get that. You can try: 'alexa, hello world'" +
            " or 'alexa, ask hello world my name is awesome Aaron'");
    }
};

const init = () =>{
  questionIndex = 0;
  score = 0;
  let allQuestions = quizContent.tunes;
  while(allQuestions.length > 0){
    let randomIndex = Math.floor(Math.random() * quizContent.tunes.length);
    questions.push(allQuestions[randomIndex]);
    allQuestions.splice(randomIndex, 1);
  }
}
