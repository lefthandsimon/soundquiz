export const questionData = {
  "tunes":
  [
    {
      "src": "1.mp3"
      "a": "camila cabello havana featuring young thug ",
      "b": "slade, but with Roy Wood off Wizzard",
      "correct": "a"
    }
  ]
}
